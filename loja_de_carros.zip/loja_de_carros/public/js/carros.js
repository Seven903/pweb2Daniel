function exibir_Carros() {
  fetch("http://127.0.0.1:3000/api/carros")
    .then((res) => {
      if (!res.ok) {
        throw new Error(res.status);
      }
      return res.json();
    })
    .then((data) => {
      data.forEach((carro) => {
        let div = document.querySelector("#car");
        let p = document.createElement("p");
        p.innerHTML = `Modelo: ${carro.modelo}, marca: ${carro.marca}, ano: ${carro.ano}, Cor: ${carro.cor}, Kilometragem: ${carro.kilometragem}, valor: R$${carro.valor}`;
        div.appendChild(p)
      });
    })
    .catch((erro) => {
      console.error(erro);
    });
}

exibir_Carros();
